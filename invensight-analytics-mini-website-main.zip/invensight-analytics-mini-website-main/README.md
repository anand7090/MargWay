# InvenSight Analytics Mini Website

A modern employee analytics and performance monitoring web application built using React, Vite, Tailwind CSS, and Supabase integration.

## Features

* Employee Dashboard
* Admin Dashboard
* Team Management
* Attendance Management
* Performance Tracking
* Analytics Dashboard
* Authentication Pages
* Responsive Design

## Installation

```bash
npm install --legacy-peer-deps
npm run dev
```

## Tech Stack

* React
* Vite
* Tailwind CSS
* Supabase
* JavaScript/TypeScript

## GitHub Repository

https://github.com/Deekshajg/invensight-analytics-mini-website
