
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.get_my_team_id() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.admin_count() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.get_my_team_id() TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.admin_count() TO anon, authenticated, service_role;
