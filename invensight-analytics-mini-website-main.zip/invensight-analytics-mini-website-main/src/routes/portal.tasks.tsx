import { createFileRoute } from "@tanstack/react-router";
import { PortalShell } from "@/components/portal/PortalShell";
import { useAuth } from "@/hooks/useAuth";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/portal/tasks")({
  component: TasksPage,
});

type Task = { id: string; title: string; description: string | null; status: string; priority: string; due_date: string | null };

function TasksPage() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);

  async function load() {
    if (!user) return;
    const { data } = await supabase
      .from("tasks")
      .select("id,title,description,status,priority,due_date")
      .eq("assignee_id", user.id)
      .order("created_at", { ascending: false });
    setTasks((data ?? []) as Task[]);
  }

  useEffect(() => { load(); }, [user]);

  async function setStatus(id: string, status: string) {
    const { error } = await supabase.from("tasks").update({ status }).eq("id", id);
    if (error) toast.error(error.message); else load();
  }

  return (
    <PortalShell title="My Tasks">
      <div className="space-y-3">
        {tasks.length === 0 && <div className="card-premium p-6 text-sm text-muted-foreground">No tasks assigned.</div>}
        {tasks.map(t => (
          <div key={t.id} className="card-premium p-5 flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-semibold">{t.title}</h3>
                <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full bg-secondary/20 text-secondary">{t.priority}</span>
              </div>
              {t.description && <p className="text-sm text-muted-foreground mt-1">{t.description}</p>}
              {t.due_date && <p className="text-xs text-muted-foreground mt-2">Due {t.due_date}</p>}
            </div>
            <select
              value={t.status}
              onChange={(e) => setStatus(t.id, e.target.value)}
              className="rounded-lg bg-background-2/60 border border-border px-3 py-2 text-sm"
            >
              <option value="pending">Pending</option>
              <option value="in_progress">In progress</option>
              <option value="done">Done</option>
            </select>
          </div>
        ))}
      </div>
    </PortalShell>
  );
}