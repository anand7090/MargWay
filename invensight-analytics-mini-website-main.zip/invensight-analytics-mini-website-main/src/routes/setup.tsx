import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { setupFirstAdmin } from "@/lib/admin.functions";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Loader2, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/setup")({
  head: () => ({
    meta: [
      { title: "Initial Setup — InvenSight Analytics Portal" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: SetupPage,
});

function SetupPage() {
  const navigate = useNavigate();
  const setup = useServerFn(setupFirstAdmin);
  const [adminExists, setAdminExists] = useState<boolean | null>(null);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({
    full_name: "",
    employee_id: "ADMIN001",
    email: "",
    password: "",
  });

  useEffect(() => {
    supabase.rpc("admin_count").then(({ data }) => {
      setAdminExists((data ?? 0) > 0);
    });
  }, []);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      await setup({ data: form });
      toast.success("Admin created. Signing you in…");
      const { error } = await supabase.auth.signInWithPassword({
        email: form.email,
        password: form.password,
      });
      if (error) throw error;
      navigate({ to: "/portal" });
    } catch (err) {
      toast.error("Setup failed", { description: (err as Error).message });
    } finally {
      setBusy(false);
    }
  }

  if (adminExists === null) {
    return <main className="min-h-screen grid place-items-center"><Loader2 className="h-6 w-6 animate-spin text-primary" /></main>;
  }

  if (adminExists) {
    return (
      <main className="min-h-screen grid place-items-center px-4">
        <div className="card-premium p-8 max-w-md text-center">
          <ShieldCheck className="h-10 w-10 text-primary mx-auto mb-3" />
          <h1 className="text-xl font-semibold">Setup already complete</h1>
          <p className="text-sm text-muted-foreground mt-2">An administrator account already exists. Sign in instead.</p>
          <Link to="/auth" className="inline-block mt-4 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground glow-gold">Go to sign in</Link>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-4 py-16">
      <div className="w-full max-w-md card-premium p-8">
        <div className="flex items-center gap-3 mb-6">
          <ShieldCheck className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-xl font-semibold">Create First Admin</h1>
            <p className="text-sm text-muted-foreground">One-time setup — disables itself afterwards.</p>
          </div>
        </div>

        <form onSubmit={onSubmit} className="space-y-3">
          <Field label="Full Name" value={form.full_name} onChange={(v) => setForm({ ...form, full_name: v })} required />
          <Field label="Employee ID" value={form.employee_id} onChange={(v) => setForm({ ...form, employee_id: v })} required />
          <Field label="Email" type="email" value={form.email} onChange={(v) => setForm({ ...form, email: v })} required />
          <Field label="Password (min 8)" type="password" value={form.password} onChange={(v) => setForm({ ...form, password: v })} required />

          <button disabled={busy} className="w-full inline-flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground glow-gold hover:brightness-110 disabled:opacity-50">
            {busy && <Loader2 className="h-4 w-4 animate-spin" />} Create administrator
          </button>
        </form>
      </div>
    </main>
  );
}

function Field({ label, value, onChange, type = "text", required }: { label: string; value: string; onChange: (v: string) => void; type?: string; required?: boolean }) {
  return (
    <label className="block">
      <span className="text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
      <input
        type={type}
        required={required}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-lg bg-background-2/60 border border-border px-3 py-2 text-sm outline-none focus:border-primary"
      />
    </label>
  );
}