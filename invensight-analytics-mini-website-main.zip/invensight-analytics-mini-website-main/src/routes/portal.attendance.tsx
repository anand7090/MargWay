import { createFileRoute } from "@tanstack/react-router";
import { PortalShell } from "@/components/portal/PortalShell";
import { useAuth } from "@/hooks/useAuth";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

export const Route = createFileRoute("/portal/attendance")({
  component: AttendancePage,
});

type Row = { id: string; date: string; status: string; check_in: string | null; check_out: string | null; notes: string | null };

function AttendancePage() {
  const { user } = useAuth();
  const [rows, setRows] = useState<Row[]>([]);
  const [busy, setBusy] = useState(false);

  async function load() {
    if (!user) return;
    const { data } = await supabase
      .from("attendance")
      .select("id,date,status,check_in,check_out,notes")
      .eq("user_id", user.id)
      .order("date", { ascending: false })
      .limit(60);
    setRows((data ?? []) as Row[]);
  }

  useEffect(() => { load(); }, [user]);

  async function checkIn() {
    if (!user) return;
    setBusy(true);
    const today = new Date().toISOString().slice(0, 10);
    const now = new Date().toISOString();
    const { error } = await supabase
      .from("attendance")
      .upsert({ user_id: user.id, date: today, status: "present", check_in: now }, { onConflict: "user_id,date" });
    setBusy(false);
    if (error) toast.error(error.message); else { toast.success("Checked in"); load(); }
  }

  async function checkOut() {
    if (!user) return;
    setBusy(true);
    const today = new Date().toISOString().slice(0, 10);
    const { error } = await supabase
      .from("attendance")
      .update({ check_out: new Date().toISOString() })
      .eq("user_id", user.id)
      .eq("date", today);
    setBusy(false);
    if (error) toast.error(error.message); else { toast.success("Checked out"); load(); }
  }

  return (
    <PortalShell title="Attendance">
      <div className="flex gap-3 mb-6">
        <button onClick={checkIn} disabled={busy} className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground glow-gold disabled:opacity-50 inline-flex items-center gap-2">
          {busy && <Loader2 className="h-4 w-4 animate-spin" />} Check in
        </button>
        <button onClick={checkOut} disabled={busy} className="rounded-lg bg-secondary px-4 py-2 text-sm font-semibold text-secondary-foreground glow-blue disabled:opacity-50">
          Check out
        </button>
      </div>

      <div className="card-premium overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-background-2/60 text-xs uppercase tracking-wider text-muted-foreground">
            <tr><th className="text-left p-3">Date</th><th className="text-left p-3">Status</th><th className="text-left p-3">Check in</th><th className="text-left p-3">Check out</th></tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr><td colSpan={4} className="p-6 text-center text-muted-foreground">No attendance records yet.</td></tr>
            ) : rows.map(r => (
              <tr key={r.id} className="border-t border-border">
                <td className="p-3">{r.date}</td>
                <td className="p-3 capitalize">{r.status}</td>
                <td className="p-3">{r.check_in ? new Date(r.check_in).toLocaleTimeString() : "—"}</td>
                <td className="p-3">{r.check_out ? new Date(r.check_out).toLocaleTimeString() : "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </PortalShell>
  );
}