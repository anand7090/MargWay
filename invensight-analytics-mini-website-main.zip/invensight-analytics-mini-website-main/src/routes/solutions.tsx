import { createFileRoute, Link } from "@tanstack/react-router";
import {
  LineChart, Workflow, CloudCog, CheckCircle2, ArrowRight,
  Store, Pill, HeartPulse, GraduationCap, Factory, Cpu,
} from "lucide-react";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { DashboardMockup } from "@/components/site/DashboardMockup";
import { Particles } from "@/components/site/Particles";

export const Route = createFileRoute("/solutions")({
  head: () => ({
    meta: [
      { title: "Solutions — InvenSight Analytics" },
      { name: "description", content: "Smart analytics solutions for growing businesses: BI dashboards, automated reporting, and cloud analytics." },
      { property: "og:title", content: "Solutions — InvenSight Analytics" },
      { property: "og:description", content: "BI dashboards, automated reporting, and cloud analytics across industries." },
    ],
  }),
  component: Solutions,
});

function Solutions() {
  return (
    <div className="min-h-screen">
      <Navbar />

      <section className="relative pt-36 pb-20">
        <Particles />
        <div className="mx-auto max-w-4xl px-6 text-center animate-fade-up">
          <span className="text-xs uppercase tracking-[0.25em] text-primary">Solutions</span>
          <h1 className="mt-4 text-4xl md:text-6xl font-semibold tracking-tight text-foreground">
            Our Business <span className="text-gradient-gold">Solutions</span>
          </h1>
          <p className="mt-5 text-lg text-muted-foreground">
            Smart Analytics Solutions for Growing Businesses.
          </p>
        </div>
      </section>

      <Solution
        eyebrow="BI Dashboard"
        title="Executive dashboards that drive action"
        items={["Track KPIs","Monitor Sales","Business Intelligence","Performance Analytics"]}
        reverse={false}
      />
      <Solution
        eyebrow="Automated Reporting"
        title="Reports delivered on autopilot"
        items={["Save Time","Reduce Manual Work","Improve Accuracy"]}
        reverse={true}
        Icon={Workflow}
      />
      <Solution
        eyebrow="Cloud Analytics"
        title="Analyze anything, from anywhere"
        items={["Cloud Access","Secure Storage","Scalable Infrastructure","Real-Time Monitoring"]}
        reverse={false}
        Icon={CloudCog}
      />

      {/* Industries */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6">
          <div className="text-center max-w-2xl mx-auto">
            <div className="text-xs uppercase tracking-[0.2em] text-primary">Industries</div>
            <h2 className="mt-3 text-3xl md:text-4xl font-semibold tracking-tight text-foreground">
              Trusted across industries
            </h2>
            <p className="mt-3 text-muted-foreground">
              From retail floors to manufacturing lines — analytics tailored to your domain.
            </p>
          </div>
          <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {[
              { I: Store, t: "Retail" },
              { I: Pill, t: "Pharma" },
              { I: HeartPulse, t: "Healthcare" },
              { I: GraduationCap, t: "Education" },
              { I: Factory, t: "Manufacturing" },
              { I: Cpu, t: "IT & SaaS" },
            ].map(i => (
              <div key={i.t} className="card-premium p-6 flex items-center gap-4">
                <div className="h-12 w-12 grid place-items-center rounded-xl bg-gradient-to-br from-secondary/30 to-primary/30 border border-border/60">
                  <i.I className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <div className="font-semibold text-foreground">{i.t}</div>
                  <div className="text-xs text-muted-foreground">Custom analytics templates</div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-16 text-center">
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground glow-gold hover:brightness-110 transition"
            >
              Talk to our team <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

function Solution({
  eyebrow, title, items, reverse, Icon = LineChart,
}: { eyebrow: string; title: string; items: string[]; reverse: boolean; Icon?: any }) {
  return (
    <section className="py-20">
      <div className={`mx-auto max-w-7xl px-6 grid lg:grid-cols-2 gap-14 items-center ${reverse ? "lg:[&>*:first-child]:order-2" : ""}`}>
        <div>
          <div className="text-xs uppercase tracking-[0.2em] text-primary">{eyebrow}</div>
          <h2 className="mt-3 text-3xl md:text-4xl font-semibold tracking-tight text-foreground">{title}</h2>
          <ul className="mt-6 grid sm:grid-cols-2 gap-3 text-sm text-muted-foreground">
            {items.map(i => (
              <li key={i} className="flex items-center gap-2 card-premium px-4 py-3">
                <CheckCircle2 className="h-4 w-4 text-primary" /> {i}
              </li>
            ))}
          </ul>
        </div>
        <div className="relative">
          <div className="card-premium glow-blue p-6">
            <div className="flex items-center justify-between">
              <Icon className="h-5 w-5 text-secondary" />
              <span className="text-xs text-muted-foreground">Live preview</span>
            </div>
            <div className="mt-4">
              <DashboardMockup />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}