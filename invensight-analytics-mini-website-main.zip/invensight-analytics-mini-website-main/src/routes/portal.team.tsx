import { createFileRoute } from "@tanstack/react-router";
import { PortalShell } from "@/components/portal/PortalShell";
import { useAuth } from "@/hooks/useAuth";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/portal/team")({
  component: TeamPage,
});

type Member = { id: string; employee_id: string; full_name: string; position: string | null; powerbi_url: string | null };

function TeamPage() {
  const { profile, isAdmin } = useAuth();
  const [members, setMembers] = useState<Member[]>([]);
  const teamId = profile?.team_id;

  useEffect(() => {
    (async () => {
      let q = supabase.from("profiles").select("id,employee_id,full_name,position,powerbi_url");
      if (!isAdmin) {
        if (!teamId) { setMembers([]); return; }
        q = q.eq("team_id", teamId);
      }
      const { data } = await q.order("full_name");
      setMembers((data ?? []) as Member[]);
    })();
  }, [teamId, isAdmin]);

  return (
    <PortalShell title={isAdmin ? "All Employees" : "My Team"}>
      {!isAdmin && !teamId && <div className="card-premium p-6 text-sm text-muted-foreground">You're not assigned to a team yet.</div>}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {members.map(m => (
          <div key={m.id} className="card-premium p-5">
            <div className="text-xs text-muted-foreground">{m.employee_id}</div>
            <div className="font-semibold mt-0.5">{m.full_name}</div>
            {m.position && <div className="text-sm text-muted-foreground">{m.position}</div>}
            <div className="mt-3 text-xs">
              {m.powerbi_url ? <span className="text-primary">Dashboard assigned</span> : <span className="text-muted-foreground">No dashboard</span>}
            </div>
          </div>
        ))}
      </div>
    </PortalShell>
  );
}