import { createFileRoute } from "@tanstack/react-router";
import { PortalShell } from "@/components/portal/PortalShell";
import { useAuth } from "@/hooks/useAuth";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { adminCreateEmployee, adminDeleteEmployee, adminResetPassword } from "@/lib/admin.functions";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Loader2, Plus, Trash2, KeyRound, Building2, UsersRound, Shield } from "lucide-react";

export const Route = createFileRoute("/portal/admin")({
  component: AdminPage,
});

type Department = { id: string; name: string; description: string | null };
type Team = { id: string; name: string; department_id: string | null; team_lead_id: string | null };
type Employee = {
  id: string; employee_id: string; full_name: string; email: string;
  position: string | null; team_id: string | null; department_id: string | null;
  powerbi_url: string | null; is_active: boolean;
  user_roles?: { role: string }[];
};

function AdminPage() {
  const { isAdmin, loading } = useAuth();
  const [tab, setTab] = useState<"employees" | "departments" | "teams" | "tasks">("employees");

  if (loading) return <PortalShell title="Administration"><Loader2 className="h-5 w-5 animate-spin" /></PortalShell>;
  if (!isAdmin) {
    return (
      <PortalShell title="Administration">
        <div className="card-premium p-6 text-sm text-muted-foreground">You don't have permission to view this page.</div>
      </PortalShell>
    );
  }

  return (
    <PortalShell title="Administration">
      <div className="flex flex-wrap gap-2 mb-6">
        {[
          { id: "employees", label: "Employees", icon: UsersRound },
          { id: "departments", label: "Departments", icon: Building2 },
          { id: "teams", label: "Teams", icon: Shield },
          { id: "tasks", label: "Assign Tasks", icon: Plus },
        ].map(t => {
          const Icon = t.icon;
          const active = tab === t.id;
          return (
            <button key={t.id} onClick={() => setTab(t.id as any)}
              className={`inline-flex items-center gap-2 rounded-lg px-3 py-2 text-sm border transition ${active ? "bg-primary text-primary-foreground border-primary glow-gold" : "border-border bg-background-2/40 text-muted-foreground hover:text-foreground"}`}>
              <Icon className="h-4 w-4" /> {t.label}
            </button>
          );
        })}
      </div>

      {tab === "employees" && <EmployeesTab />}
      {tab === "departments" && <DepartmentsTab />}
      {tab === "teams" && <TeamsTab />}
      {tab === "tasks" && <TasksTab />}
    </PortalShell>
  );
}

/* -------------------- EMPLOYEES -------------------- */
function EmployeesTab() {
  const create = useServerFn(adminCreateEmployee);
  const remove = useServerFn(adminDeleteEmployee);
  const reset = useServerFn(adminResetPassword);

  const [employees, setEmployees] = useState<Employee[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [busy, setBusy] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    email: "", password: "", employee_id: "", full_name: "",
    role: "employee" as "admin"|"team_lead"|"employee",
    phone: "", position: "", department_id: "", team_id: "", powerbi_url: "",
  });

  async function load() {
    const [e, d, t] = await Promise.all([
      supabase.from("profiles").select("id,employee_id,full_name,email,position,team_id,department_id,powerbi_url,is_active").order("created_at"),
      supabase.from("departments").select("*").order("name"),
      supabase.from("teams").select("*").order("name"),
    ]);
    // Fetch roles separately (RLS allows admin to read all)
    const { data: roles } = await supabase.from("user_roles").select("user_id,role");
    const byUser: Record<string, string[]> = {};
    (roles ?? []).forEach((r: any) => { (byUser[r.user_id] ||= []).push(r.role); });
    const list = ((e.data ?? []) as Employee[]).map(emp => ({ ...emp, user_roles: (byUser[emp.id] ?? []).map(r => ({ role: r })) }));
    setEmployees(list);
    setDepartments((d.data ?? []) as Department[]);
    setTeams((t.data ?? []) as Team[]);
  }

  useEffect(() => { load(); }, []);

  async function onCreate(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      await create({ data: {
        ...form,
        department_id: form.department_id || null,
        team_id: form.team_id || null,
        phone: form.phone || null,
        position: form.position || null,
        powerbi_url: form.powerbi_url || null,
      } as any });
      toast.success("Employee created");
      setShowForm(false);
      setForm({ email: "", password: "", employee_id: "", full_name: "", role: "employee", phone: "", position: "", department_id: "", team_id: "", powerbi_url: "" });
      load();
    } catch (err) { toast.error((err as Error).message); }
    finally { setBusy(false); }
  }

  async function onSavePowerBI(emp: Employee, url: string) {
    const { error } = await supabase.from("profiles").update({ powerbi_url: url || null }).eq("id", emp.id);
    if (error) toast.error(error.message); else { toast.success("Dashboard saved"); load(); }
  }

  async function onAssignTeam(emp: Employee, team_id: string | null) {
    const { error } = await supabase.from("profiles").update({ team_id }).eq("id", emp.id);
    if (error) toast.error(error.message); else load();
  }

  async function onDelete(emp: Employee) {
    if (!confirm(`Delete ${emp.full_name}? This cannot be undone.`)) return;
    try { await remove({ data: { user_id: emp.id } }); toast.success("Deleted"); load(); }
    catch (err) { toast.error((err as Error).message); }
  }

  async function onResetPwd(emp: Employee) {
    const pwd = prompt(`New password for ${emp.full_name} (min 8 chars):`);
    if (!pwd || pwd.length < 8) return;
    try { await reset({ data: { user_id: emp.id, password: pwd } }); toast.success("Password reset"); }
    catch (err) { toast.error((err as Error).message); }
  }

  return (
    <div className="space-y-5">
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-semibold">Employees ({employees.length})</h2>
        <button onClick={() => setShowForm(!showForm)} className="rounded-lg bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground glow-gold inline-flex items-center gap-1.5">
          <Plus className="h-4 w-4" /> {showForm ? "Cancel" : "Add Employee"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={onCreate} className="card-premium p-5 grid md:grid-cols-2 gap-3">
          <Input label="Full Name" v={form.full_name} on={(v)=>setForm({...form, full_name:v})} required />
          <Input label="Employee ID" v={form.employee_id} on={(v)=>setForm({...form, employee_id:v})} required />
          <Input label="Email" type="email" v={form.email} on={(v)=>setForm({...form, email:v})} required />
          <Input label="Password (min 8)" type="password" v={form.password} on={(v)=>setForm({...form, password:v})} required />
          <div>
            <label className="text-xs uppercase tracking-wider text-muted-foreground">Role</label>
            <select value={form.role} onChange={(e)=>setForm({...form, role: e.target.value as any})} className="mt-1 w-full rounded-lg bg-background-2/60 border border-border px-3 py-2 text-sm">
              <option value="employee">Employee</option>
              <option value="team_lead">Team Lead</option>
              <option value="admin">Admin</option>
            </select>
          </div>
          <Input label="Position" v={form.position} on={(v)=>setForm({...form, position:v})} />
          <div>
            <label className="text-xs uppercase tracking-wider text-muted-foreground">Department</label>
            <select value={form.department_id} onChange={(e)=>setForm({...form, department_id: e.target.value})} className="mt-1 w-full rounded-lg bg-background-2/60 border border-border px-3 py-2 text-sm">
              <option value="">—</option>
              {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs uppercase tracking-wider text-muted-foreground">Team</label>
            <select value={form.team_id} onChange={(e)=>setForm({...form, team_id: e.target.value})} className="mt-1 w-full rounded-lg bg-background-2/60 border border-border px-3 py-2 text-sm">
              <option value="">—</option>
              {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
          </div>
          <Input label="Phone" v={form.phone} on={(v)=>setForm({...form, phone:v})} />
          <Input label="Power BI URL" v={form.powerbi_url} on={(v)=>setForm({...form, powerbi_url:v})} placeholder="https://app.powerbi.com/..." />
          <button disabled={busy} className="md:col-span-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground glow-gold inline-flex items-center justify-center gap-2 disabled:opacity-50">
            {busy && <Loader2 className="h-4 w-4 animate-spin" />} Create employee
          </button>
        </form>
      )}

      <div className="card-premium overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-background-2/60 text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="text-left p-3">ID</th>
              <th className="text-left p-3">Name</th>
              <th className="text-left p-3">Role</th>
              <th className="text-left p-3">Team</th>
              <th className="text-left p-3">Power BI URL</th>
              <th className="text-right p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {employees.length === 0 && (
              <tr><td colSpan={6} className="p-6 text-center text-muted-foreground">No employees yet. Add your first one above.</td></tr>
            )}
            {employees.map(emp => (
              <tr key={emp.id} className="border-t border-border align-middle">
                <td className="p-3 font-mono text-xs">{emp.employee_id}</td>
                <td className="p-3">
                  <div className="font-medium">{emp.full_name}</div>
                  <div className="text-xs text-muted-foreground">{emp.email}</div>
                </td>
                <td className="p-3 capitalize">{emp.user_roles?.map(r => r.role.replace("_"," ")).join(", ") || "—"}</td>
                <td className="p-3">
                  <select defaultValue={emp.team_id ?? ""} onChange={(e)=>onAssignTeam(emp, e.target.value || null)} className="rounded-lg bg-background-2/60 border border-border px-2 py-1 text-xs">
                    <option value="">—</option>
                    {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                  </select>
                </td>
                <td className="p-3 min-w-[260px]">
                  <PowerBIInput initial={emp.powerbi_url ?? ""} onSave={(v)=>onSavePowerBI(emp, v)} />
                </td>
                <td className="p-3 text-right whitespace-nowrap">
                  <button onClick={()=>onResetPwd(emp)} className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground mr-2">
                    <KeyRound className="h-3.5 w-3.5" /> Reset
                  </button>
                  <button onClick={()=>onDelete(emp)} className="inline-flex items-center gap-1 text-xs text-destructive hover:brightness-125">
                    <Trash2 className="h-3.5 w-3.5" /> Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function PowerBIInput({ initial, onSave }: { initial: string; onSave: (v:string)=>void }) {
  const [v, setV] = useState(initial);
  return (
    <div className="flex gap-2">
      <input value={v} onChange={(e)=>setV(e.target.value)} placeholder="https://app.powerbi.com/..." className="flex-1 rounded-lg bg-background-2/60 border border-border px-2 py-1 text-xs" />
      <button onClick={()=>onSave(v)} className="rounded-lg bg-secondary px-2 py-1 text-xs text-secondary-foreground">Save</button>
    </div>
  );
}

function Input({ label, v, on, type="text", required, placeholder }: { label: string; v: string; on: (s:string)=>void; type?:string; required?:boolean; placeholder?:string }) {
  return (
    <label className="block">
      <span className="text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
      <input type={type} required={required} value={v} placeholder={placeholder} onChange={(e)=>on(e.target.value)} className="mt-1 w-full rounded-lg bg-background-2/60 border border-border px-3 py-2 text-sm outline-none focus:border-primary" />
    </label>
  );
}

/* -------------------- DEPARTMENTS -------------------- */
function DepartmentsTab() {
  const [list, setList] = useState<Department[]>([]);
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");

  async function load() {
    const { data } = await supabase.from("departments").select("*").order("name");
    setList((data ?? []) as Department[]);
  }
  useEffect(() => { load(); }, []);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    const { error } = await supabase.from("departments").insert({ name, description: desc || null });
    if (error) toast.error(error.message); else { toast.success("Department created"); setName(""); setDesc(""); load(); }
  }
  async function del(id: string) {
    if (!confirm("Delete department?")) return;
    const { error } = await supabase.from("departments").delete().eq("id", id);
    if (error) toast.error(error.message); else load();
  }

  return (
    <div className="space-y-5">
      <form onSubmit={add} className="card-premium p-5 flex flex-wrap gap-3 items-end">
        <Input label="Name" v={name} on={setName} required />
        <Input label="Description" v={desc} on={setDesc} />
        <button className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground glow-gold">Add</button>
      </form>
      <div className="card-premium overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-background-2/60 text-xs uppercase tracking-wider text-muted-foreground">
            <tr><th className="text-left p-3">Name</th><th className="text-left p-3">Description</th><th></th></tr>
          </thead>
          <tbody>
            {list.length === 0 ? <tr><td colSpan={3} className="p-6 text-center text-muted-foreground">No departments yet.</td></tr> : list.map(d => (
              <tr key={d.id} className="border-t border-border">
                <td className="p-3 font-medium">{d.name}</td>
                <td className="p-3 text-muted-foreground">{d.description || "—"}</td>
                <td className="p-3 text-right"><button onClick={()=>del(d.id)} className="text-xs text-destructive">Delete</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* -------------------- TEAMS -------------------- */
function TeamsTab() {
  const [teams, setTeams] = useState<Team[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [profiles, setProfiles] = useState<{ id: string; full_name: string; employee_id: string }[]>([]);
  const [name, setName] = useState("");
  const [deptId, setDeptId] = useState("");
  const [leadId, setLeadId] = useState("");

  async function load() {
    const [t, d, p] = await Promise.all([
      supabase.from("teams").select("*").order("name"),
      supabase.from("departments").select("*").order("name"),
      supabase.from("profiles").select("id,full_name,employee_id").order("full_name"),
    ]);
    setTeams((t.data ?? []) as Team[]);
    setDepartments((d.data ?? []) as Department[]);
    setProfiles((p.data ?? []) as any);
  }
  useEffect(() => { load(); }, []);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    const { error } = await supabase.from("teams").insert({ name, department_id: deptId || null, team_lead_id: leadId || null });
    if (error) toast.error(error.message); else { toast.success("Team created"); setName(""); setDeptId(""); setLeadId(""); load(); }
  }

  async function setLead(teamId: string, lead: string | null) {
    const { error } = await supabase.from("teams").update({ team_lead_id: lead }).eq("id", teamId);
    if (error) toast.error(error.message); else load();
  }

  async function del(id: string) {
    if (!confirm("Delete team?")) return;
    const { error } = await supabase.from("teams").delete().eq("id", id);
    if (error) toast.error(error.message); else load();
  }

  return (
    <div className="space-y-5">
      <form onSubmit={add} className="card-premium p-5 grid md:grid-cols-4 gap-3 items-end">
        <Input label="Team Name" v={name} on={setName} required />
        <div>
          <label className="text-xs uppercase tracking-wider text-muted-foreground">Department</label>
          <select value={deptId} onChange={(e)=>setDeptId(e.target.value)} className="mt-1 w-full rounded-lg bg-background-2/60 border border-border px-3 py-2 text-sm">
            <option value="">—</option>
            {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
        </div>
        <div>
          <label className="text-xs uppercase tracking-wider text-muted-foreground">Team Lead</label>
          <select value={leadId} onChange={(e)=>setLeadId(e.target.value)} className="mt-1 w-full rounded-lg bg-background-2/60 border border-border px-3 py-2 text-sm">
            <option value="">—</option>
            {profiles.map(p => <option key={p.id} value={p.id}>{p.full_name} ({p.employee_id})</option>)}
          </select>
        </div>
        <button className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground glow-gold">Add team</button>
      </form>

      <div className="card-premium overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-background-2/60 text-xs uppercase tracking-wider text-muted-foreground">
            <tr><th className="text-left p-3">Team</th><th className="text-left p-3">Department</th><th className="text-left p-3">Lead</th><th></th></tr>
          </thead>
          <tbody>
            {teams.length === 0 ? <tr><td colSpan={4} className="p-6 text-center text-muted-foreground">No teams yet.</td></tr> : teams.map(t => (
              <tr key={t.id} className="border-t border-border">
                <td className="p-3 font-medium">{t.name}</td>
                <td className="p-3">{departments.find(d=>d.id===t.department_id)?.name ?? "—"}</td>
                <td className="p-3">
                  <select defaultValue={t.team_lead_id ?? ""} onChange={(e)=>setLead(t.id, e.target.value || null)} className="rounded-lg bg-background-2/60 border border-border px-2 py-1 text-xs">
                    <option value="">—</option>
                    {profiles.map(p => <option key={p.id} value={p.id}>{p.full_name}</option>)}
                  </select>
                </td>
                <td className="p-3 text-right"><button onClick={()=>del(t.id)} className="text-xs text-destructive">Delete</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* -------------------- TASK ASSIGN -------------------- */
function TasksTab() {
  const { user } = useAuth();
  const [profiles, setProfiles] = useState<{ id: string; full_name: string; employee_id: string }[]>([]);
  const [form, setForm] = useState({ title: "", description: "", assignee_id: "", priority: "medium", due_date: "" });
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.from("profiles").select("id,full_name,employee_id").order("full_name").then(({ data }) => {
      setProfiles((data ?? []) as any);
    });
  }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.assignee_id) { toast.error("Pick an assignee"); return; }
    setBusy(true);
    const { error } = await supabase.from("tasks").insert({
      title: form.title,
      description: form.description || null,
      assignee_id: form.assignee_id,
      assigned_by: user?.id ?? null,
      priority: form.priority,
      due_date: form.due_date || null,
    });
    setBusy(false);
    if (error) toast.error(error.message);
    else { toast.success("Task assigned"); setForm({ title: "", description: "", assignee_id: "", priority: "medium", due_date: "" }); }
  }

  return (
    <form onSubmit={submit} className="card-premium p-5 grid md:grid-cols-2 gap-3 max-w-3xl">
      <Input label="Title" v={form.title} on={(v)=>setForm({...form, title:v})} required />
      <div>
        <label className="text-xs uppercase tracking-wider text-muted-foreground">Assignee</label>
        <select value={form.assignee_id} onChange={(e)=>setForm({...form, assignee_id: e.target.value})} className="mt-1 w-full rounded-lg bg-background-2/60 border border-border px-3 py-2 text-sm">
          <option value="">— select —</option>
          {profiles.map(p => <option key={p.id} value={p.id}>{p.full_name} ({p.employee_id})</option>)}
        </select>
      </div>
      <div className="md:col-span-2">
        <label className="text-xs uppercase tracking-wider text-muted-foreground">Description</label>
        <textarea value={form.description} onChange={(e)=>setForm({...form, description: e.target.value})} rows={3} className="mt-1 w-full rounded-lg bg-background-2/60 border border-border px-3 py-2 text-sm" />
      </div>
      <div>
        <label className="text-xs uppercase tracking-wider text-muted-foreground">Priority</label>
        <select value={form.priority} onChange={(e)=>setForm({...form, priority: e.target.value})} className="mt-1 w-full rounded-lg bg-background-2/60 border border-border px-3 py-2 text-sm">
          <option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option>
        </select>
      </div>
      <Input label="Due date" type="date" v={form.due_date} on={(v)=>setForm({...form, due_date:v})} />
      <button disabled={busy} className="md:col-span-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground glow-gold inline-flex items-center justify-center gap-2 disabled:opacity-50">
        {busy && <Loader2 className="h-4 w-4 animate-spin" />} Assign task
      </button>
    </form>
  );
}