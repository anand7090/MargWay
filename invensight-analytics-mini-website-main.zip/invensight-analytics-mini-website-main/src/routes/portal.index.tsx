import { createFileRoute, Link } from "@tanstack/react-router";
import { PortalShell } from "@/components/portal/PortalShell";
import { useAuth } from "@/hooks/useAuth";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { BarChart3, CalendarCheck, ListTodo, Users } from "lucide-react";

export const Route = createFileRoute("/portal/")({
  component: PortalDashboard,
});

function PortalDashboard() {
  const { user, profile, isAdmin, isTeamLead } = useAuth();
  const [stats, setStats] = useState({ tasks: 0, openTasks: 0, attendance: 0 });

  useEffect(() => {
    if (!user) return;
    (async () => {
      const [tAll, tOpen, att] = await Promise.all([
        supabase.from("tasks").select("id", { count: "exact", head: true }).eq("assignee_id", user.id),
        supabase.from("tasks").select("id", { count: "exact", head: true }).eq("assignee_id", user.id).neq("status", "done"),
        supabase.from("attendance").select("id", { count: "exact", head: true }).eq("user_id", user.id),
      ]);
      setStats({ tasks: tAll.count ?? 0, openTasks: tOpen.count ?? 0, attendance: att.count ?? 0 });
    })();
  }, [user]);

  return (
    <PortalShell title={`Welcome, ${profile?.full_name?.split(" ")[0] ?? "there"}`}>
      <p className="text-muted-foreground -mt-4 mb-8">
        {isAdmin ? "Administrator overview" : isTeamLead ? "Team lead overview" : "Your personal workspace"}
      </p>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        <Stat icon={ListTodo} label="My open tasks" value={stats.openTasks} sub={`${stats.tasks} total`} link="/portal/tasks" />
        <Stat icon={CalendarCheck} label="Attendance entries" value={stats.attendance} sub="recent" link="/portal/attendance" />
        <Stat icon={BarChart3} label="Performance" value={profile?.powerbi_url ? "Live" : "Not set"} sub="Power BI dashboard" link="/portal/performance" />
        {(isTeamLead || isAdmin) && (
          <Stat icon={Users} label="Team management" value="Open" sub="Members & performance" link="/portal/team" />
        )}
      </div>
    </PortalShell>
  );
}

function Stat({ icon: Icon, label, value, sub, link }: { icon: any; label: string; value: number | string; sub?: string; link: string }) {
  return (
    <Link to={link} className="card-premium p-5 block group">
      <div className="flex items-center justify-between">
        <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
        <Icon className="h-4 w-4 text-primary" />
      </div>
      <div className="mt-3 text-3xl font-semibold text-gradient-gold">{value}</div>
      {sub && <div className="text-xs text-muted-foreground mt-1">{sub}</div>}
    </Link>
  );
}