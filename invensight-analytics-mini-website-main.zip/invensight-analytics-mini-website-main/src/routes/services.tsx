import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Database, BarChart3, Brain, Wrench, GraduationCap, Headphones,
  ArrowRight, Search, PencilRuler, Rocket, LifeBuoy, Check,
} from "lucide-react";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { Particles } from "@/components/site/Particles";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — InvenSight Analytics" },
      { name: "description", content: "Expert data services: consulting, custom dashboard development, ETL & data integration, AI/ML, training and 24/7 support." },
      { property: "og:title", content: "Services — InvenSight Analytics" },
      { property: "og:description", content: "Hands-on data consulting, custom builds, integrations, AI/ML, training and support — engineered around your team." },
    ],
  }),
  component: Services,
});

const services = [
  {
    Icon: Brain,
    title: "Data Strategy & Consulting",
    desc: "We audit your data stack, map KPIs to business outcomes, and craft a roadmap your team can actually execute.",
    bullets: ["Data maturity audit", "KPI & metric design", "Tooling roadmap"],
    tag: "Most Popular",
  },
  {
    Icon: BarChart3,
    title: "Custom Dashboard Development",
    desc: "Pixel-perfect, executive-ready dashboards built on your data — fully branded, responsive, and blazingly fast.",
    bullets: ["Power BI / Tableau / Looker", "Custom web dashboards", "Mobile-first design"],
  },
  {
    Icon: Database,
    title: "Data Integration & ETL",
    desc: "Connect every source — CRMs, ERPs, ad platforms, spreadsheets — into one clean, governed warehouse.",
    bullets: ["100+ source connectors", "Automated ETL pipelines", "Data quality monitoring"],
  },
  {
    Icon: Wrench,
    title: "AI & Machine Learning",
    desc: "Forecasting, churn prediction, anomaly detection and GenAI assistants embedded directly into your workflow.",
    bullets: ["Forecasting models", "Custom AI assistants", "Anomaly detection"],
  },
  {
    Icon: GraduationCap,
    title: "Training & Enablement",
    desc: "Upskill your team with hands-on workshops in analytics, SQL, BI tools, and data storytelling.",
    bullets: ["Live workshops", "Role-based curriculums", "Certification tracks"],
  },
  {
    Icon: Headphones,
    title: "24/7 Managed Support",
    desc: "A dedicated success engineer plus round-the-clock monitoring so your data never goes dark.",
    bullets: ["Dedicated engineer", "SLA-backed response", "Proactive monitoring"],
  },
];

const process = [
  { Icon: Search,      step: "01", t: "Discover",  d: "Deep-dive workshops to understand your data, goals and gaps." },
  { Icon: PencilRuler, step: "02", t: "Design",    d: "Architect the stack, models and dashboards around your KPIs." },
  { Icon: Rocket,      step: "03", t: "Deliver",   d: "Build, integrate and launch — in sprints, not quarters." },
  { Icon: LifeBuoy,    step: "04", t: "Support",   d: "Ongoing optimization, training and 24/7 monitoring." },
];

function Services() {
  return (
    <div className="min-h-screen">
      <Navbar />

      <section className="relative pt-36 pb-16">
        <Particles />
        <div className="mx-auto max-w-4xl px-6 text-center animate-fade-up">
          <span className="text-xs uppercase tracking-[0.25em] text-primary">Services</span>
          <h1 className="mt-4 text-4xl md:text-6xl font-semibold tracking-tight text-foreground">
            Expert Data <span className="text-gradient-gold">Services</span>, Delivered End-to-End
          </h1>
          <p className="mt-5 text-lg text-muted-foreground">
            From strategy to deployment — our specialists plug into your team and turn raw data into a measurable advantage.
          </p>
        </div>
      </section>

      {/* Services grid */}
      <section className="py-12">
        <div className="mx-auto max-w-7xl px-6 grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((s) => (
            <div
              key={s.title}
              className="card-premium p-6 group relative overflow-hidden hover:-translate-y-1 transition-transform duration-300"
            >
              {s.tag && (
                <span className="absolute top-4 right-4 text-[10px] uppercase tracking-widest rounded-full bg-primary/15 text-primary px-2 py-1 border border-primary/30">
                  {s.tag}
                </span>
              )}
              <div className="h-12 w-12 grid place-items-center rounded-xl bg-gradient-to-br from-secondary/30 to-primary/30 border border-border/60 glow-blue">
                <s.Icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="mt-5 text-lg font-semibold text-foreground">{s.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{s.desc}</p>
              <ul className="mt-5 space-y-2">
                {s.bullets.map((b) => (
                  <li key={b} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Check className="h-4 w-4 text-primary" /> {b}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* Process */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6">
          <div className="text-center max-w-2xl mx-auto">
            <div className="text-xs uppercase tracking-[0.2em] text-primary">How We Work</div>
            <h2 className="mt-3 text-3xl md:text-4xl font-semibold tracking-tight text-foreground">
              A proven 4-step delivery process
            </h2>
            <p className="mt-3 text-muted-foreground">
              Lean sprints, clear milestones, zero black boxes.
            </p>
          </div>

          <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {process.map((p) => (
              <div key={p.step} className="card-premium p-6 relative">
                <div className="text-5xl font-bold text-gradient-gold/40 opacity-70">{p.step}</div>
                <p.Icon className="h-5 w-5 text-secondary mt-3" />
                <h4 className="mt-3 font-semibold text-foreground">{p.t}</h4>
                <p className="mt-1 text-sm text-muted-foreground">{p.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Engagement models */}
      <section className="pb-24">
        <div className="mx-auto max-w-7xl px-6">
          <div className="text-center max-w-2xl mx-auto">
            <div className="text-xs uppercase tracking-[0.2em] text-primary">Engagement Models</div>
            <h2 className="mt-3 text-3xl md:text-4xl font-semibold tracking-tight text-foreground">
              Flexible ways to work with us
            </h2>
          </div>
          <div className="mt-12 grid md:grid-cols-3 gap-6">
            {[
              { t: "Project-Based", d: "Fixed scope, fixed timeline. Ideal for one-off builds and migrations.", price: "From $4,999" },
              { t: "Dedicated Team", d: "A pod of analysts & engineers embedded with your team, full-time.", price: "From $12k / mo" },
              { t: "Retainer Support", d: "Ongoing optimization, monitoring and on-demand analytics requests.", price: "From $1,499 / mo" },
            ].map((m) => (
              <div key={m.t} className="card-premium p-6 flex flex-col">
                <div className="text-sm uppercase tracking-widest text-primary">{m.t}</div>
                <p className="mt-3 text-muted-foreground text-sm flex-1">{m.d}</p>
                <div className="mt-5 text-2xl font-semibold text-foreground">{m.price}</div>
              </div>
            ))}
          </div>

          <div className="mt-14 text-center">
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground glow-gold hover:brightness-110 transition"
            >
              Start your project <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
