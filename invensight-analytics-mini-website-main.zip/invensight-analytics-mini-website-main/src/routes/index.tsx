import { createFileRoute } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";
import {
  BarChart3, FileBarChart, Cloud, Zap, Database, Rocket, ShieldCheck,
  ArrowRight, CheckCircle2,
} from "lucide-react";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { DashboardMockup } from "@/components/site/DashboardMockup";
import { Counter } from "@/components/site/Counter";
import { Particles } from "@/components/site/Particles";
import { Courses } from "@/components/site/Courses";
import { EnquiryForm } from "@/components/site/EnquiryForm";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "InvenSight Analytics — Turn Business Data Into Real Decisions" },
      { name: "description", content: "Automate reporting, monitor performance, and visualize KPIs with InvenSight's intelligent SaaS analytics platform." },
      { property: "og:title", content: "InvenSight Analytics — Turn Business Data Into Real Decisions" },
      { property: "og:description", content: "BI dashboards, automated reports, and cloud analytics for modern enterprises." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen">
      <Navbar />

      {/* Hero */}
      <section className="relative pt-28 pb-14">
        <Particles />
        <div className="mx-auto max-w-7xl px-6 grid lg:grid-cols-2 gap-14 items-center">
          <div className="animate-fade-up">
            <span className="inline-flex items-center gap-2 rounded-full glass px-3 py-1 text-xs text-muted-foreground">
              <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse-glow" />
              Enterprise SaaS · Built for analytics teams
            </span>
            <h1 className="mt-5 text-4xl md:text-6xl font-semibold leading-[1.05] tracking-tight text-foreground">
              Turn Your Business Data Into{" "}
              <span className="text-gradient-gold">Real Decisions</span>
            </h1>
            <p className="mt-6 text-lg text-muted-foreground max-w-xl">
              Helping businesses automate reporting, monitor performance, visualize KPIs,
              and make faster decisions through intelligent SaaS solutions.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground glow-gold hover:brightness-110 transition"
              >
                Book Demo <ArrowRight className="h-4 w-4" />
              </Link>
              <Link
                to="/solutions"
                className="inline-flex items-center gap-2 rounded-lg glass px-5 py-3 text-sm font-semibold text-foreground hover:border-secondary/60 transition"
              >
                View Solutions
              </Link>
            </div>
            <div className="mt-10 grid grid-cols-3 gap-4 max-w-md text-xs text-muted-foreground">
              {["SOC 2 Ready","99.99% Uptime","GDPR Compliant"].map(t => (
                <div key={t} className="flex items-center gap-1.5">
                  <ShieldCheck className="h-3.5 w-3.5 text-primary" /> {t}
                </div>
              ))}
            </div>
          </div>

          <div className="relative animate-fade-up [animation-delay:200ms]">
            <DashboardMockup />
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="relative py-14">
        <div className="mx-auto max-w-7xl px-6">
          <SectionHead
            eyebrow="Services"
            title="Everything you need to operationalize data"
            sub="Three pillars that turn raw data into measurable business outcomes."
          />
          <div className="mt-14 grid md:grid-cols-3 gap-6">
            {[
              {
                I: BarChart3, title: "BI Dashboards",
                items: ["Real-time KPI Monitoring","Interactive Reports","Executive Insights"]
              },
              {
                I: FileBarChart, title: "Automated Reporting",
                items: ["Daily Reports","Weekly Reports","Automated Email Reports"]
              },
              {
                I: Cloud, title: "Cloud Analytics",
                items: ["Secure Data Access","Real-Time Insights","Anywhere Availability"]
              },
            ].map(s => (
              <div key={s.title} className="card-premium p-7 group">
                <div className="h-12 w-12 grid place-items-center rounded-xl bg-gradient-to-br from-secondary/30 to-primary/30 border border-border/60 group-hover:glow-gold transition">
                  <s.I className="h-5 w-5 text-primary" />
                </div>
                <h3 className="mt-5 text-xl font-semibold text-foreground">{s.title}</h3>
                <ul className="mt-4 space-y-2.5 text-sm text-muted-foreground">
                  {s.items.map(i => (
                    <li key={i} className="flex items-center gap-2">
                      <CheckCircle2 className="h-4 w-4 text-primary" /> {i}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why */}
      <section className="py-14 relative">
        <div className="mx-auto max-w-7xl px-6">
          <SectionHead
            eyebrow="Why InvenSight"
            title="Why businesses choose us"
            sub="A modern analytics stack engineered for speed, scale, and clarity."
          />
          <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {[
              { I: Database, t: "Data Driven Decisions", d: "Unified data, single source of truth." },
              { I: Zap, t: "Real-Time Analytics", d: "Sub-second queries on live data." },
              { I: Rocket, t: "Business Automation", d: "Automate reports, alerts, and workflows." },
              { I: Cloud, t: "Cloud Scalability", d: "Elastic infrastructure with zero ops." },
            ].map(c => (
              <div key={c.t} className="card-premium p-6">
                <c.I className="h-6 w-6 text-secondary" />
                <div className="mt-4 font-semibold text-foreground">{c.t}</div>
                <div className="mt-1.5 text-sm text-muted-foreground">{c.d}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-14">
        <div className="mx-auto max-w-7xl px-6">
          <div className="card-premium p-10 md:p-14">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              {[
                { v: 100, s: "+", l: "Businesses Served" },
                { v: 500, s: "+", l: "Reports Generated" },
                { v: 98, s: "%", l: "Client Satisfaction" },
                { v: 24, s: "/7", l: "Support" },
              ].map(st => (
                <div key={st.l}>
                  <div className="text-4xl md:text-5xl font-semibold text-gradient-gold">
                    <Counter value={st.v} suffix={st.s} />
                  </div>
                  <div className="mt-2 text-sm text-muted-foreground">{st.l}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Courses */}
      <Courses />

      {/* Smart Enquiry */}
      <EnquiryForm />

      {/* CTA */}
      <section className="py-12">
        <div className="mx-auto max-w-5xl px-6">
          <div className="relative overflow-hidden rounded-3xl p-10 md:p-14 text-center glass glow-blue">
            <div className="absolute inset-0 -z-10 opacity-50 bg-[radial-gradient(ellipse_at_top,theme(colors.transparent),transparent),radial-gradient(ellipse_at_top_left,var(--secondary),transparent_60%),radial-gradient(ellipse_at_bottom_right,var(--primary),transparent_60%)]" />
            <h2 className="text-3xl md:text-5xl font-semibold tracking-tight text-foreground">
              Ready to Transform Your Business?
            </h2>
            <p className="mt-4 text-muted-foreground">Book a Free Demo Today.</p>
            <Link
              to="/contact"
              className="mt-8 inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground glow-gold hover:brightness-110 transition"
            >
              Schedule Consultation <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

function SectionHead({ eyebrow, title, sub }: { eyebrow: string; title: string; sub: string }) {
  return (
    <div className="max-w-2xl mx-auto text-center">
      <div className="text-xs uppercase tracking-[0.2em] text-primary">{eyebrow}</div>
      <h2 className="mt-3 text-3xl md:text-4xl font-semibold tracking-tight text-foreground">{title}</h2>
      <p className="mt-3 text-muted-foreground">{sub}</p>
    </div>
  );
}
