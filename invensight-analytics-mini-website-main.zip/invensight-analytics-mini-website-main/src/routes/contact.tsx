import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Phone, Mail, Globe, Clock, Linkedin, Send, CheckCircle2, MessageCircle } from "lucide-react";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { Particles } from "@/components/site/Particles";
import { ConnectButton } from "@/components/site/ConnectModal";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — InvenSight Analytics" },
      { name: "description", content: "Let's build smarter businesses together. Get in touch with the InvenSight Analytics team." },
      { property: "og:title", content: "Contact — InvenSight Analytics" },
      { property: "og:description", content: "Talk to our analytics experts." },
    ],
  }),
  component: Contact,
});

function Contact() {
  const [sent, setSent] = useState(false);
  return (
    <div className="min-h-screen">
      <Navbar />

      <section className="relative pt-36 pb-16">
        <Particles />
        <div className="mx-auto max-w-4xl px-6 text-center animate-fade-up">
          <span className="text-xs uppercase tracking-[0.25em] text-primary">Contact</span>
          <h1 className="mt-4 text-4xl md:text-6xl font-semibold tracking-tight text-foreground">
            Let's Build <span className="text-gradient-gold">Smarter Businesses</span> Together
          </h1>
          <p className="mt-5 text-lg text-muted-foreground">
            Tell us about your data — we'll show you what's possible.
          </p>
        </div>
      </section>

      <section className="pb-24">
        <div className="mx-auto max-w-7xl px-6 grid lg:grid-cols-5 gap-8">
          <form
            onSubmit={(e) => { e.preventDefault(); setSent(true); }}
            className="lg:col-span-3 card-premium p-8"
          >
            <div className="grid sm:grid-cols-2 gap-5">
              <Field label="Name" name="name" placeholder="Ananya Sharma" required />
              <Field label="Email" name="email" type="email" placeholder="you@company.com" />
              <Field label="Phone" name="phone" placeholder="+91 98765 43210" required />
              <Field label="Company Name" name="company" placeholder="Acme Corp" />
            </div>
            <div className="mt-5">
              <label className="text-xs uppercase tracking-wider text-muted-foreground">Business Requirement</label>
              <textarea
                required
                rows={5}
                placeholder="Tell us about your analytics goals..."
                className="mt-2 w-full rounded-lg bg-background-2/60 border border-border px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/70 focus:outline-none focus:border-primary transition"
              />
            </div>
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <button
                type="submit"
                className="inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground glow-gold hover:brightness-110 transition"
              >
                {sent ? (<><CheckCircle2 className="h-4 w-4" /> Message Sent</>) : (<>Submit <Send className="h-4 w-4" /></>)}
              </button>
              <ConnectButton />
            </div>
          </form>

          <aside className="lg:col-span-2 card-premium p-8 space-y-6">
            <div>
              <div className="text-xl font-semibold text-foreground">
                InvenSight <span className="text-gradient-gold">Analytics</span>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">Enterprise-grade analytics, built for the cloud.</p>
            </div>
            <InfoRow I={Phone} l="Phone / WhatsApp" v="+91 72690 07967" href="tel:+917269007967" />
            <InfoRow I={Mail} l="Email" v="invensightanalytics@gmail.com" href="mailto:invensightanalytics@gmail.com" />
            <InfoRow I={Globe} l="Website" v="invensightanalytics.com" href="https://invensightanalytics.com/" />
            <InfoRow I={Linkedin} l="LinkedIn" v="InvenSight Analytics" href="https://www.linkedin.com/company/invensight-analytics/" />
            <InfoRow I={MessageCircle} l="WhatsApp" v="Chat with us" href="https://wa.me/917269007967" />
            <InfoRow I={Clock} l="Response Time" v="Within 2 hours on WhatsApp" />
          </aside>
        </div>
      </section>

      <Footer />
    </div>
  );
}

function Field({ label, name, type = "text", placeholder, required: isRequired }: { label: string; name: string; type?: string; placeholder?: string; required?: boolean }) {
  return (
    <div>
      <label className="text-xs uppercase tracking-wider text-muted-foreground">
        {label}
        {isRequired && <span className="text-primary ml-1">*</span>}
      </label>
      <input
        required={isRequired}
        type={type}
        name={name}
        placeholder={placeholder}
        className="mt-2 w-full rounded-lg bg-background-2/60 border border-border px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/70 focus:outline-none focus:border-primary transition"
      />
    </div>
  );
}

function InfoRow({ I, l, v, href }: { I: any; l: string; v: string; href?: string }) {
  const content = (
    <div className="flex items-start gap-3">
      <div className="h-9 w-9 grid place-items-center rounded-lg bg-gradient-to-br from-secondary/30 to-primary/30 border border-border/60 shrink-0">
        <I className="h-4 w-4 text-primary" />
      </div>
      <div>
        <div className="text-xs uppercase tracking-wider text-muted-foreground">{l}</div>
        <div className="text-sm text-foreground">{v}</div>
      </div>
    </div>
  );
  return href ? (
    <a href={href} target="_blank" rel="noopener noreferrer" className="block hover:opacity-80 transition">
      {content}
    </a>
  ) : content;
}