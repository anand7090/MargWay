import { createFileRoute } from "@tanstack/react-router";
import { PortalShell } from "@/components/portal/PortalShell";
import { useAuth } from "@/hooks/useAuth";
import { BarChart3 } from "lucide-react";

export const Route = createFileRoute("/portal/performance")({
  component: PerformancePage,
});

function PerformancePage() {
  const { profile } = useAuth();
  const url = profile?.powerbi_url;
  return (
    <PortalShell title="My Performance">
      <p className="text-muted-foreground -mt-4 mb-6 text-sm">Live Power BI dashboard assigned by your administrator.</p>
      {url ? (
        <div className="card-premium p-2 overflow-hidden">
          <iframe
            title="Power BI Dashboard"
            src={url}
            className="w-full rounded-lg"
            style={{ height: "78vh", border: 0 }}
            allowFullScreen
          />
        </div>
      ) : (
        <div className="card-premium p-10 text-center">
          <BarChart3 className="h-10 w-10 text-primary mx-auto mb-3" />
          <h2 className="text-lg font-semibold">No dashboard assigned yet</h2>
          <p className="text-sm text-muted-foreground mt-2">
            Your administrator hasn't linked a Power BI report to your profile. Once they do, your live performance dashboard will appear here.
          </p>
        </div>
      )}
    </PortalShell>
  );
}