import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/portal")({
  head: () => ({
    meta: [
      { title: "Employee Portal — InvenSight Analytics" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: () => <Outlet />,
});