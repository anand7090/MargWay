import { createFileRoute } from "@tanstack/react-router";
import { PortalShell } from "@/components/portal/PortalShell";
import { useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/portal/profile")({
  component: ProfilePage,
});

function ProfilePage() {
  const { profile, user } = useAuth();
  if (!profile) {
    return <PortalShell title="My Profile"><div className="card-premium p-6 text-sm text-muted-foreground">Profile not set up yet.</div></PortalShell>;
  }
  const rows: Array<[string, string | null]> = [
    ["Employee ID", profile.employee_id],
    ["Full Name", profile.full_name],
    ["Email", profile.email ?? user?.email ?? null],
    ["Phone", profile.phone],
    ["Position", profile.position],
    ["Joined", profile.joined_at],
    ["Status", profile.is_active ? "Active" : "Inactive"],
  ];
  return (
    <PortalShell title="My Profile">
      <div className="card-premium p-6 max-w-2xl">
        <dl className="grid sm:grid-cols-2 gap-x-6 gap-y-4">
          {rows.map(([k, v]) => (
            <div key={k}>
              <dt className="text-xs uppercase tracking-wider text-muted-foreground">{k}</dt>
              <dd className="text-sm font-medium mt-1">{v || <span className="text-muted-foreground">—</span>}</dd>
            </div>
          ))}
        </dl>
        <p className="mt-6 text-xs text-muted-foreground">To update profile details, contact your administrator.</p>
      </div>
    </PortalShell>
  );
}