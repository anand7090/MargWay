import { Link, useNavigate, useLocation } from "@tanstack/react-router";
import { useAuth } from "@/hooks/useAuth";
import { LayoutDashboard, User, BarChart3, CalendarCheck, ListTodo, Users, Shield, LogOut, Loader2 } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import logo from "@/assets/is-analytics-logo.jpeg";

export function PortalShell({ children, title }: { children: ReactNode; title?: string }) {
  const { user, loading, profile, roles, isAdmin, isTeamLead, signOut } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  if (loading || !user) {
    return (
      <div className="min-h-screen grid place-items-center">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  const nav = [
    { to: "/portal", label: "Dashboard", icon: LayoutDashboard, exact: true },
    { to: "/portal/profile", label: "My Profile", icon: User },
    { to: "/portal/performance", label: "My Performance", icon: BarChart3 },
    { to: "/portal/attendance", label: "Attendance", icon: CalendarCheck },
    { to: "/portal/tasks", label: "Tasks", icon: ListTodo },
    ...(isTeamLead || isAdmin ? [{ to: "/portal/team", label: "My Team", icon: Users }] : []),
    ...(isAdmin ? [{ to: "/portal/admin", label: "Administration", icon: Shield }] : []),
  ];

  const roleLabel = isAdmin ? "Administrator" : isTeamLead ? "Team Lead" : "Employee";

  async function handleSignOut() {
    await signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <aside className="md:w-64 md:min-h-screen border-b md:border-b-0 md:border-r border-border bg-background-2/40 backdrop-blur">
        <div className="p-5 flex items-center gap-3">
          <img src={logo} alt="" className="h-9 w-9 rounded-lg glow-gold" />
          <div>
            <div className="text-sm font-semibold">InvenSight</div>
            <div className="text-xs text-muted-foreground">Employee Portal</div>
          </div>
        </div>

        <div className="px-5 pb-4">
          <div className="rounded-lg bg-background/60 border border-border p-3">
            <div className="text-xs text-muted-foreground">{profile?.employee_id ?? "—"}</div>
            <div className="text-sm font-medium truncate">{profile?.full_name ?? user.email}</div>
            <div className="mt-1 inline-block rounded-full bg-primary/15 text-primary text-[10px] px-2 py-0.5 font-semibold uppercase tracking-wider">{roleLabel}</div>
          </div>
        </div>

        <nav className="px-3 space-y-1">
          {nav.map((n) => {
            const active = n.exact ? location.pathname === n.to : location.pathname.startsWith(n.to);
            const Icon = n.icon;
            return (
              <Link
                key={n.to}
                to={n.to}
                className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition ${
                  active ? "bg-primary/15 text-primary border border-primary/30" : "text-muted-foreground hover:bg-background/60 hover:text-foreground"
                }`}
              >
                <Icon className="h-4 w-4" />
                {n.label}
              </Link>
            );
          })}
        </nav>

        <div className="px-3 mt-6 mb-6">
          <button
            onClick={handleSignOut}
            className="w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-muted-foreground hover:bg-destructive/15 hover:text-destructive transition"
          >
            <LogOut className="h-4 w-4" /> Sign out
          </button>
        </div>
      </aside>

      <main className="flex-1 p-6 md:p-10 max-w-7xl mx-auto w-full">
        {title && <h1 className="text-2xl font-semibold tracking-tight mb-6">{title}</h1>}
        {roles.length === 0 ? (
          <div className="card-premium p-6 text-sm text-muted-foreground">
            Your account has no roles assigned yet. Please contact an administrator.
          </div>
        ) : (
          children
        )}
      </main>
    </div>
  );
}