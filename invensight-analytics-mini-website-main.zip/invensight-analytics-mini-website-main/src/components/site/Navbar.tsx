import { Link } from "@tanstack/react-router";
import logo from "@/assets/is-analytics-logo.jpeg";
import { ConnectButton } from "@/components/site/ConnectModal";

const items = [
  { to: "/", label: "Home" },
  { to: "/services", label: "Services" },
  { to: "/solutions", label: "Solutions" },
  { to: "/contact", label: "Contact" },
  { to: "/portal", label: "Portal" },
] as const;

export function Navbar() {
  return (
    <header className="fixed top-0 inset-x-0 z-50">
      <div className="mx-auto mt-4 max-w-7xl px-4">
        <nav className="glass flex items-center justify-between rounded-2xl px-5 py-3">

          <Link to="/" className="flex items-center gap-2">
            <img
              src={logo}
              alt="IS Analytics logo"
              className="h-9 w-9 rounded-lg object-cover glow-gold"
            />
            <span className="font-semibold tracking-tight text-foreground">
              InvenSight <span className="text-gradient-gold">Analytics</span>
            </span>
          </Link>

          <ul className="hidden md:flex items-center gap-7 text-sm text-muted-foreground">

            {items.map((i, idx) => (
              <li key={idx}>
                <Link
                  to={i.to}
                  activeOptions={{ exact: i.to === "/" }}
                  activeProps={{ className: "text-foreground" }}
                  className="hover:text-foreground transition-colors"
                >
                  {i.label}
                </Link>
              </li>
            ))}

            <li>
              <a
                href="#enquiry"
                className="hover:text-foreground transition-colors"
              >
                Enquiry
              </a>
            </li>

          </ul>

          <div className="flex items-center gap-2">

            <ConnectButton className="hidden sm:inline-flex" />

            <Link
              to="/contact"
              className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground glow-gold hover:brightness-110 transition"
            >
              Book Free Demo
            </Link>

          </div>

        </nav>
      </div>
    </header>
  );
}