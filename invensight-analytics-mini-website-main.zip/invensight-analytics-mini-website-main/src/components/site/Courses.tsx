import { useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  GraduationCap, Clock, CheckCircle2, ArrowRight, Sparkles,
  Briefcase, TrendingUp,
} from "lucide-react";

type Course = {
  name: string;
  duration: string;
  price: string;
  benefits: string[];
  badge?: string;
  featured?: boolean;
};

const featured: Course[] = [
  {
    name: "Data Analytics Career Program",
    duration: "4–5 Months",
    price: "₹24,999 – ₹34,999",
    badge: "Most Popular",
    featured: true,
    benefits: [
      "Excel + Advanced Excel + SQL",
      "Power BI Dashboard Projects",
      "Resume & Interview Prep",
      "Perceived value ₹43K+",
    ],
  },
  {
    name: "Power Platform Bundle",
    duration: "2–3 Months",
    price: "₹27,999",
    benefits: [
      "Power BI end-to-end",
      "Power Automate workflows",
      "Dashboard Projects",
      "Microsoft Power Platform aligned",
    ],
  },
  {
    name: "Azure Data Engineering Bundle",
    duration: "5–6 Months",
    price: "₹59,999 – ₹74,999",
    badge: "Premium",
    benefits: [
      "Azure Data Factory + Databricks",
      "PySpark & Lakehouse Concepts",
      "End-to-End Industry Projects",
      "Career-ready portfolio",
    ],
  },
];

const individual: Course[] = [
  { name: "Microsoft Excel", duration: "3–4 Weeks", price: "₹6,999", benefits: ["Formulas & Functions", "Charts & Pivot Tables", "Business reporting"] },
  { name: "Advanced Excel", duration: "4–5 Weeks", price: "₹9,999", benefits: ["Power Query", "DAX & Power Pivot", "Automation with VBA basics"] },
  { name: "Power BI", duration: "6–8 Weeks", price: "₹16,999", benefits: ["Data modeling", "DAX measures", "Executive dashboards"] },
  { name: "Power Automate", duration: "4–5 Weeks", price: "₹12,999", benefits: ["Cloud & Desktop flows", "Approvals & triggers", "Process automation"] },
  { name: "SQL Basic", duration: "3–4 Weeks", price: "₹8,999", benefits: ["Queries & joins", "Aggregations", "Reporting datasets"] },
  { name: "Advanced SQL", duration: "5–6 Weeks", price: "₹14,999", benefits: ["Window functions", "CTEs & optimization", "Analytics workloads"] },
];

const career: Course[] = [
  { name: "HTML & CSS", duration: "3–4 Weeks", price: "₹11,999", benefits: ["Responsive layouts", "Modern CSS", "Portfolio projects"] },
  { name: "Azure Data Factory", duration: "5–6 Weeks", price: "₹24,999", benefits: ["Pipelines & datasets", "ETL orchestration", "Real-world ingestion"] },
  { name: "Azure Databricks", duration: "6–8 Weeks", price: "₹34,999", benefits: ["Lakehouse architecture", "Delta Lake", "Notebook workflows"] },
  { name: "PySpark", duration: "5–6 Weeks", price: "₹29,999", benefits: ["Distributed data processing", "DataFrames API", "Big-data projects"] },
];

function CourseCard({ c }: { c: Course }) {
  return (
    <div className={`card-premium p-4 flex flex-col group ${c.featured ? "glow-gold" : ""}`}>
      <div className="flex items-start justify-between gap-2">
        <div className="h-8 w-8 grid place-items-center rounded-lg bg-gradient-to-br from-secondary/30 to-primary/30 border border-border/60">
          <GraduationCap className="h-4 w-4 text-primary" />
        </div>
        {c.badge && (
          <span className="rounded-full bg-primary/15 px-2 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-primary border border-primary/30">
            {c.badge}
          </span>
        )}
      </div>
      <h3 className="mt-2.5 text-sm font-semibold text-foreground leading-snug">{c.name}</h3>
      <div className="mt-1 flex items-center justify-between gap-2 text-[11px] text-muted-foreground">
        <span className="inline-flex items-center gap-1"><Clock className="h-3 w-3 text-secondary" />{c.duration}</span>
        <span className="font-semibold text-gradient-gold text-sm">{c.price}</span>
      </div>
      <ul className="mt-2.5 space-y-1 text-[11.5px] text-muted-foreground flex-1">
        {c.benefits.slice(0, 3).map((b) => (
          <li key={b} className="flex items-start gap-1.5">
            <CheckCircle2 className="h-3 w-3 text-primary mt-0.5 shrink-0" /> <span>{b}</span>
          </li>
        ))}
      </ul>
      <Link
        to="/contact"
        className="mt-3 inline-flex items-center justify-center gap-1.5 rounded-md bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground hover:brightness-110 transition"
      >
        Enroll Now <ArrowRight className="h-3 w-3" />
      </Link>
    </div>
  );
}

const tabs = [
  { id: "featured", label: "Featured", Icon: Sparkles, items: featured },
  { id: "individual", label: "Internship & Training", Icon: Briefcase, items: individual },
  { id: "career", label: "Career Development", Icon: TrendingUp, items: career },
] as const;

export function Courses() {
  const [active, setActive] = useState<typeof tabs[number]["id"]>("featured");
  const current = tabs.find((t) => t.id === active)!;
  return (
    <section id="courses" className="relative py-16 scroll-mt-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="max-w-2xl mx-auto text-center animate-fade-up">
          <div className="text-xs uppercase tracking-[0.2em] text-primary">Learn. Build. Grow.</div>
          <h2 className="mt-2 text-2xl md:text-3xl font-semibold tracking-tight text-foreground">
            Courses & <span className="text-gradient-gold">Training Programs</span>
          </h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Industry-focused training — from Excel fundamentals to Azure Data Engineering.
          </p>
        </div>

        <div className="mt-6 flex flex-wrap justify-center gap-2">
          {tabs.map((t) => {
            const isActive = t.id === active;
            return (
              <button
                key={t.id}
                onClick={() => setActive(t.id)}
                className={`inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-xs font-medium transition border ${
                  isActive
                    ? "bg-primary text-primary-foreground border-primary glow-gold"
                    : "glass text-muted-foreground border-transparent hover:text-foreground"
                }`}
              >
                <t.Icon className="h-3.5 w-3.5" /> {t.label}
              </button>
            );
          })}
        </div>

        <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3 animate-fade-up">
          {current.items.map((c) => <CourseCard key={c.name} c={c} />)}
        </div>
      </div>
    </section>
  );
}