import { useEffect, useState } from "react";
import { Instagram, Linkedin, Facebook, Twitter, Youtube, MessageCircle, X, Share2 } from "lucide-react";

const LINKS = [
  { I: Instagram, label: "Instagram", href: "https://www.instagram.com/is_analytics_saas/?__pwa=1#", color: "from-pink-500 to-orange-400" },
  { I: Linkedin, label: "LinkedIn", href: "https://www.linkedin.com/company/invensight-analytics/", color: "from-sky-500 to-blue-600" },
  { I: Facebook, label: "Facebook", href: "https://facebook.com/invensightanalytics", color: "from-blue-500 to-indigo-600" },
  { I: Twitter, label: "Twitter / X", href: "https://twitter.com/invensight", color: "from-slate-500 to-slate-800" },
  { I: Youtube, label: "YouTube", href: "https://youtube.com/@invensightanalytics", color: "from-red-500 to-rose-600" },
  { I: MessageCircle, label: "WhatsApp", href: "https://wa.me/917269007967", color: "from-emerald-500 to-green-600" },
];

export function ConnectButton({ className = "" }: { className?: string }) {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className={`inline-flex items-center gap-2 rounded-lg glass px-4 py-2 text-sm font-semibold text-foreground hover:border-secondary/60 transition ${className}`}
      >
        <Share2 className="h-4 w-4 text-primary" /> Connect With Us
      </button>

      {open && (
        <div
          className="fixed inset-0 z-[70] grid place-items-center px-4 animate-fade-up"
          onClick={() => setOpen(false)}
        >
          <div className="absolute inset-0 bg-background/70 backdrop-blur-md" />
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative glass rounded-2xl border border-border/60 p-6 md:p-8 w-full max-w-lg shadow-2xl"
          >
            <button
              onClick={() => setOpen(false)}
              className="absolute top-3 right-3 h-8 w-8 grid place-items-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-background-2/60 transition"
              aria-label="Close"
            >
              <X className="h-4 w-4" />
            </button>

            <div className="text-center">
              <span className="text-xs uppercase tracking-[0.2em] text-primary">Connect</span>
              <h3 className="mt-2 text-2xl md:text-3xl font-semibold text-foreground">
                Follow <span className="text-gradient-gold">InvenSight</span>
              </h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Join us across platforms — insights, tutorials and product updates.
              </p>
            </div>

            <div className="mt-6 grid grid-cols-2 sm:grid-cols-3 gap-3">
              {LINKS.map(({ I, label, href, color }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group relative overflow-hidden rounded-xl border border-border/60 bg-background-2/40 p-4 flex flex-col items-center gap-2 hover:border-primary/60 transition hover:-translate-y-0.5"
                >
                  <div
                    className={`absolute inset-0 opacity-0 group-hover:opacity-20 transition bg-gradient-to-br ${color}`}
                  />
                  <div className="relative h-10 w-10 grid place-items-center rounded-lg bg-gradient-to-br from-secondary/30 to-primary/30 border border-border/60 group-hover:glow-gold transition">
                    <I className="h-5 w-5 text-foreground" />
                  </div>
                  <span className="relative text-xs font-medium text-foreground">{label}</span>
                </a>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
}