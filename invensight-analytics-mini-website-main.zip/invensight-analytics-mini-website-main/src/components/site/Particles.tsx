export function Particles() {
  const dots = Array.from({ length: 22 });
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden -z-10">
      {dots.map((_, i) => {
        const left = (i * 47) % 100;
        const top = (i * 73) % 100;
        const delay = (i % 7) * 0.6;
        const size = 2 + (i % 4);
        const gold = i % 3 === 0;
        return (
          <span
            key={i}
            className="absolute rounded-full animate-pulse-glow"
            style={{
              left: `${left}%`,
              top: `${top}%`,
              width: size,
              height: size,
              background: gold ? "var(--primary)" : "var(--secondary)",
              boxShadow: `0 0 12px ${gold ? "var(--primary)" : "var(--secondary)"}`,
              animationDelay: `${delay}s`,
              opacity: 0.6,
            }}
          />
        );
      })}
    </div>
  );
}