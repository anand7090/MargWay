import { Link } from "@tanstack/react-router";

export function Footer() {
  return (
    <footer className="mt-32 border-t border-border/60">
      <div className="mx-auto max-w-7xl px-6 py-12 grid gap-8 md:grid-cols-4 text-sm">
        <div>
          <div className="font-semibold text-foreground">
            InvenSight <span className="text-gradient-gold">Analytics</span>
          </div>
          <p className="mt-3 text-muted-foreground max-w-xs">
            Intelligent SaaS analytics for modern enterprises.
          </p>
        </div>
        <div>
          <div className="text-foreground font-medium mb-3">Product</div>
          <ul className="space-y-2 text-muted-foreground">
            <li><Link to="/solutions" className="hover:text-foreground">BI Dashboards</Link></li>
            <li><Link to="/solutions" className="hover:text-foreground">Automated Reports</Link></li>
            <li><Link to="/solutions" className="hover:text-foreground">Cloud Analytics</Link></li>
          </ul>
        </div>
        <div>
          <div className="text-foreground font-medium mb-3">Company</div>
          <ul className="space-y-2 text-muted-foreground">
            <li><Link to="/" className="hover:text-foreground">About</Link></li>
            <li><Link to="/contact" className="hover:text-foreground">Contact</Link></li>
          </ul>
        </div>
        <div>
          <div className="text-foreground font-medium mb-3">Contact</div>
          <ul className="space-y-2 text-muted-foreground">
            <li>invensightanalytics@gmail.com</li>
            <li>+91 72690 07967</li>
            <li>
              <a href="https://invensightanalytics.com/" target="_blank" rel="noopener noreferrer" className="hover:text-foreground transition">
                invensightanalytics.com
              </a>
            </li>
            <li>
              <a href="https://www.linkedin.com/company/invensight-analytics/" target="_blank" rel="noopener noreferrer" className="hover:text-foreground transition">
                LinkedIn · InvenSight Analytics
              </a>
            </li>
            <li>WhatsApp · Within 2 hours</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border/60 py-5 text-center text-xs text-muted-foreground">
        © 2025 InvenSight Analytics. All rights reserved. | Microsoft Power Platform Partner India
      </div>
    </footer>
  );
}