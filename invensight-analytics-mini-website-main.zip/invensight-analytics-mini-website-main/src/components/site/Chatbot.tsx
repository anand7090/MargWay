import { useEffect, useRef, useState } from "react";
import { X, Send, Bot } from "lucide-react";

type Msg = { role: "bot" | "user"; text: string };

const QUICK = [
  "Courses",
  "Internships",
  "BI Dashboards",
  "Automated Reporting",
  "Cloud Analytics",
  "Book Demo",
];

function reply(input: string): string {
  const q = input.toLowerCase();
  if (q.includes("course"))
    return "We offer Featured Courses, Internship & Training Programs, and Career Development tracks in Power BI, Tableau, SQL, Python and Data Analytics. Want me to share pricing?";
  if (q.includes("intern"))
    return "Our Internship & Training Programs run 1–3 months with live projects, mentorship and a verified certificate. Perfect for students and freshers.";
  if (q.includes("bi") || q.includes("dashboard"))
    return "Our BI Dashboards deliver real-time KPI monitoring, interactive reports and executive insights — built on Power BI, Tableau and custom stacks.";
  if (q.includes("report") || q.includes("automat"))
    return "Automated Reporting covers daily/weekly schedules, email delivery and alerting so your team never chases numbers again.";
  if (q.includes("cloud"))
    return "Cloud Analytics gives you secure data access, real-time insights and anywhere availability with elastic, zero-ops infrastructure.";
  if (q.includes("demo") || q.includes("book"))
    return "Awesome! You can book a free demo from the Contact page or WhatsApp us at +91 72690 07967. Want me to open the contact form?";
  if (q.includes("price") || q.includes("cost") || q.includes("fee"))
    return "Pricing depends on scope and team size. Share your requirement on the Enquiry form and we'll send a tailored quote within 2 hours.";
  if (q.includes("contact") || q.includes("whatsapp") || q.includes("email"))
    return "Reach us at invensightanalytics@gmail.com or WhatsApp +91 72690 07967. We reply within 2 hours.";
  if (q.includes("hi") || q.includes("hello") || q.includes("hey"))
    return "Hi there! 👋 I'm InvenBot. Ask me about Courses, Internships, BI Dashboards, Automated Reporting, Cloud Analytics or Book a Demo.";
  return "I can help with Courses, Internships, BI Dashboards, Automated Reporting, Cloud Analytics and booking a demo. Try one of the suggestions below.";
}

export function Chatbot() {
  const [open, setOpen] = useState(false);
  const [hover, setHover] = useState(false);
  const [teaser, setTeaser] = useState<string | null>(null);
  const [messages, setMessages] = useState<Msg[]>([
    { role: "bot", text: "Hi! I'm InvenBot 🤖 — ask me anything about InvenSight Analytics." },
  ]);
  const [input, setInput] = useState("");
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, open]);

  // Idle teaser bubble — rotates friendly prompts when chat is closed
  useEffect(() => {
    if (open) {
      setTeaser(null);
      return;
    }
    const lines = [
      "Psst… got a doubt? 🤔",
      "Need help? I don't bite 😄",
      "Ask me anything — I'm caffeinated ☕",
      "Curious about our courses? 🎓",
      "Let's talk analytics 📊",
      "Still here! Tap me 👇",
    ];
    let i = 0;
    const show = () => {
      setTeaser(lines[i % lines.length]);
      i++;
      window.setTimeout(() => setTeaser(null), 4500);
    };
    const first = window.setTimeout(show, 4000);
    const loop = window.setInterval(show, 14000);
    return () => {
      window.clearTimeout(first);
      window.clearInterval(loop);
    };
  }, [open]);

  function send(text: string) {
    const t = text.trim();
    if (!t) return;
    setMessages((m) => [...m, { role: "user", text: t }]);
    setInput("");
    setTimeout(() => {
      setMessages((m) => [...m, { role: "bot", text: reply(t) }]);
    }, 450);
  }

  return (
    <>
      {/* Idle teaser bubble */}
      {!open && teaser && (
        <div className="fixed bottom-24 right-6 z-[60] max-w-[220px] animate-fade-up">
          <div className="relative glass rounded-2xl rounded-br-sm border border-border/60 px-3.5 py-2 text-xs text-foreground shadow-xl">
            {teaser}
            <span className="absolute -bottom-1.5 right-5 h-3 w-3 rotate-45 bg-background-2/80 border-r border-b border-border/60" />
          </div>
        </div>
      )}

      {/* Floating emoji mascot button */}
      <button
        onClick={() => setOpen((v) => !v)}
        onMouseEnter={() => setHover(true)}
        onMouseLeave={() => setHover(false)}
        aria-label="Open chat"
        className="group fixed bottom-6 right-6 z-[60] h-16 w-16 grid place-items-center rounded-full bg-gradient-to-br from-primary to-secondary text-primary-foreground glow-gold shadow-xl transition-transform duration-300 hover:scale-110 active:scale-95 animate-pulse-glow"
      >
        {open ? (
          <X className="h-6 w-6" />
        ) : (
          <span
            aria-hidden
            className="text-3xl leading-none select-none transition-transform duration-300 group-hover:rotate-[8deg] group-hover:scale-110"
          >
            {hover ? "😄" : "🤖"}
          </span>
        )}
        {!open && (
          <>
            <span className="absolute -top-1 -right-1 h-3.5 w-3.5 rounded-full bg-emerald-400 border-2 border-background" />
            <span className="absolute inset-0 -z-10 rounded-full bg-primary/40 blur-xl opacity-70" />
          </>
        )}
      </button>

      {open && (
        <div className="fixed bottom-24 right-6 z-[60] w-[92vw] max-w-sm origin-bottom-right animate-fade-up">
          <div className="glass rounded-2xl overflow-hidden border border-border/60 shadow-2xl flex flex-col h-[70vh] max-h-[560px]">
            {/* header */}
            <div className="flex items-center gap-3 px-4 py-3 border-b border-border/60 bg-background-2/60">
              <div className="h-9 w-9 grid place-items-center rounded-lg bg-gradient-to-br from-secondary/40 to-primary/40 border border-border/60">
                <Bot className="h-4 w-4 text-primary" />
              </div>
              <div className="flex-1">
                <div className="text-sm font-semibold text-foreground">InvenBot</div>
                <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> Online · replies instantly
                </div>
              </div>
              <button onClick={() => setOpen(false)} className="text-muted-foreground hover:text-foreground transition" aria-label="Close chat">
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* messages */}
            <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3 text-sm">
              {messages.map((m, i) => (
                <div
                  key={i}
                  className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={
                      m.role === "user"
                        ? "max-w-[80%] rounded-2xl rounded-br-sm bg-primary text-primary-foreground px-3.5 py-2 shadow"
                        : "max-w-[85%] rounded-2xl rounded-bl-sm bg-background-2/70 border border-border/60 text-foreground px-3.5 py-2"
                    }
                  >
                    {m.text}
                  </div>
                </div>
              ))}
              <div ref={endRef} />
            </div>

            {/* quick chips */}
            <div className="px-3 pb-2 flex gap-1.5 flex-wrap">
              {QUICK.map((q) => (
                <button
                  key={q}
                  onClick={() => send(q)}
                  className="text-[11px] px-2.5 py-1 rounded-full border border-border/60 bg-background-2/40 text-muted-foreground hover:text-foreground hover:border-primary/60 transition"
                >
                  {q}
                </button>
              ))}
            </div>

            {/* input */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                send(input);
              }}
              className="flex items-center gap-2 p-3 border-t border-border/60 bg-background-2/60"
            >
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type your message..."
                className="flex-1 rounded-lg bg-background/60 border border-border px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/70 focus:outline-none focus:border-primary transition"
              />
              <button
                type="submit"
                className="h-9 w-9 grid place-items-center rounded-lg bg-primary text-primary-foreground glow-gold hover:brightness-110 transition"
                aria-label="Send"
              >
                <Send className="h-4 w-4" />
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}