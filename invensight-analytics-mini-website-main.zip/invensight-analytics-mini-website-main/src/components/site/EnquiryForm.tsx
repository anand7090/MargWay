import { useRef, useState } from "react";
import { Upload, X, Send, CheckCircle2, Sparkles, FileText } from "lucide-react";

export function EnquiryForm() {
  const [sent, setSent] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleFile = (f: File | null) => {
    if (f) setFile(f);
  };

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };
  const onDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };
  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const dropped = e.dataTransfer.files?.[0] ?? null;
    handleFile(dropped);
  };

  return (
    <section id="enquiry" className="relative py-20">
      <div className="mx-auto max-w-5xl px-6">
        <div className="max-w-2xl mx-auto text-center">
          <div className="text-xs uppercase tracking-[0.2em] text-primary inline-flex items-center gap-2 justify-center">
            <Sparkles className="h-3.5 w-3.5" /> Smart Enquiry
          </div>
          <h2 className="mt-3 text-3xl md:text-4xl font-semibold tracking-tight text-foreground">
            Have a project in mind? <span className="text-gradient-gold">Tell us about it</span>
          </h2>
          <p className="mt-3 text-muted-foreground">
            Share your requirements and attach any reference documents. We'll get back within 2 hours.
          </p>
        </div>

        <form
          onSubmit={(e) => { e.preventDefault(); setSent(true); }}
          className="mt-10 card-premium p-8"
        >
          <div className="grid sm:grid-cols-2 gap-5">
            <EField label="Name" name="name" placeholder="Ananya Sharma" required />
            <EField label="Phone" name="phone" placeholder="+91 98765 43210" required />
            <EField label="Email" name="email" type="email" placeholder="you@company.com" />
            <EField label="Company" name="company" placeholder="Acme Corp" />
          </div>

          <div className="mt-5">
            <label className="text-xs uppercase tracking-wider text-muted-foreground">
              Your Enquiry <span className="text-primary ml-1">*</span>
            </label>
            <textarea
              required
              rows={5}
              placeholder="Describe your business needs, goals, or questions..."
              className="mt-2 w-full rounded-lg bg-background-2/60 border border-border px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/70 focus:outline-none focus:border-primary transition"
            />
          </div>

          {/* Upload Supporting Documents */}
          <div className="mt-8">
            <h3 className="text-lg font-semibold text-foreground">Upload Supporting Documents</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Please upload any relevant documents related to your enquiry, such as payment receipts, quotations, requirement documents, project details, or previous discussion files.
            </p>

            <div className="mt-4 flex flex-wrap gap-2">
              {["PDF", "JPG", "JPEG", "PNG", "DOC", "DOCX"].map(fmt => (
                <span key={fmt} className="inline-flex items-center rounded-full bg-background-2/60 border border-border px-2.5 py-1 text-[11px] text-muted-foreground">
                  <FileText className="h-3 w-3 mr-1 text-primary" />
                  {fmt}
                </span>
              ))}
            </div>

            <input
              ref={fileRef}
              type="file"
              accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
              onChange={(e) => handleFile(e.target.files?.[0] ?? null)}
              className="hidden"
            />

            <div
              onDragOver={onDragOver}
              onDragLeave={onDragLeave}
              onDrop={onDrop}
              onClick={() => fileRef.current?.click()}
              className={
                "mt-5 cursor-pointer rounded-xl border-2 border-dashed px-6 py-8 text-center transition " +
                (isDragOver
                  ? "border-primary bg-primary/5"
                  : "border-border hover:border-primary/60 bg-background-2/30")
              }
            >
              <div className="mx-auto h-10 w-10 grid place-items-center rounded-full bg-primary/10">
                <Upload className="h-5 w-5 text-primary" />
              </div>
              <p className="mt-3 text-sm font-medium text-foreground">
                {file ? file.name : "Drag & drop your file here"}
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                {file
                  ? `${Math.ceil(file.size / 1024)} KB · Click to change`
                  : "or click to browse from your device"}
              </p>
            </div>

            {file && (
              <div className="mt-3 inline-flex items-center gap-2 rounded-lg bg-background-2/60 border border-border px-3 py-2 text-xs text-foreground">
                <span className="truncate max-w-[200px]">{file.name}</span>
                <span className="text-muted-foreground">({Math.ceil(file.size / 1024)} KB)</span>
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); setFile(null); if (fileRef.current) fileRef.current.value = ""; }}
                  className="text-muted-foreground hover:text-foreground transition"
                  aria-label="Remove file"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            )}
          </div>

          <div className="mt-8">
            <button
              type="submit"
              className="inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground glow-gold hover:brightness-110 transition"
            >
              {sent ? (<><CheckCircle2 className="h-4 w-4" /> Enquiry Sent</>) : (<>Send Enquiry <Send className="h-4 w-4" /></>)}
            </button>
          </div>
        </form>
      </div>
    </section>
  );
}

function EField({ label, name, type = "text", placeholder, required: isRequired }: { label: string; name: string; type?: string; placeholder?: string; required?: boolean }) {
  return (
    <div>
      <label className="text-xs uppercase tracking-wider text-muted-foreground">
        {label}
        {isRequired && <span className="text-primary ml-1">*</span>}
      </label>
      <input
        required={isRequired}
        type={type}
        name={name}
        placeholder={placeholder}
        className="mt-2 w-full rounded-lg bg-background-2/60 border border-border px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/70 focus:outline-none focus:border-primary transition"
      />
    </div>
  );
}
