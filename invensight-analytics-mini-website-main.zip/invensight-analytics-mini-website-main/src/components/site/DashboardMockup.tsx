import { TrendingUp, DollarSign, Users, Activity, ArrowUpRight } from "lucide-react";

export function DashboardMockup() {
  const bars = [40, 65, 50, 80, 60, 95, 72, 88, 70, 92];
  return (
    <div className="relative">
      {/* floating widgets */}
      <div className="absolute -top-6 -left-6 z-20 card-premium p-4 w-52 animate-float">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>Revenue</span>
          <DollarSign className="h-3.5 w-3.5 text-primary" />
        </div>
        <div className="mt-1 text-2xl font-semibold text-foreground">₹4.82Cr</div>
        <div className="text-xs text-emerald-400 flex items-center gap-1">
          <ArrowUpRight className="h-3 w-3" /> +18.4% this month
        </div>
      </div>

      <div className="absolute -bottom-6 -right-4 z-20 card-premium p-4 w-56 animate-float-slow">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>Active Users</span>
          <Users className="h-3.5 w-3.5 text-secondary" />
        </div>
        <div className="mt-1 text-2xl font-semibold text-foreground">12,408</div>
        <div className="mt-2 h-1.5 bg-muted rounded-full overflow-hidden">
          <div className="h-full w-3/4 bg-gradient-to-r from-secondary to-primary" />
        </div>
      </div>

      {/* main dashboard */}
      <div className="card-premium glow-blue p-6 relative z-10">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-xs text-muted-foreground">Executive Overview</div>
            <div className="text-lg font-semibold text-foreground">Sales Performance</div>
          </div>
          <div className="flex gap-2 text-xs text-muted-foreground">
            <span className="px-2 py-1 rounded-md bg-muted">7D</span>
            <span className="px-2 py-1 rounded-md bg-primary/20 text-primary">30D</span>
            <span className="px-2 py-1 rounded-md bg-muted">QTR</span>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 mt-5">
          {[
            { l: "Orders", v: "8,214", c: "text-primary", I: TrendingUp },
            { l: "Conversion", v: "4.92%", c: "text-secondary", I: Activity },
            { l: "AOV", v: "₹3,140", c: "text-emerald-400", I: DollarSign },
          ].map((k) => (
            <div key={k.l} className="rounded-lg bg-background-2/60 p-3 border border-border/60">
              <div className="flex items-center justify-between text-[10px] uppercase tracking-wider text-muted-foreground">
                <span>{k.l}</span>
                <k.I className={`h-3 w-3 ${k.c}`} />
              </div>
              <div className={`mt-1 text-base font-semibold ${k.c}`}>{k.v}</div>
            </div>
          ))}
        </div>

        {/* chart */}
        <div className="mt-6 h-44 flex items-end gap-2">
          {bars.map((h, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-1">
              <div
                className="w-full rounded-t-md bg-gradient-to-t from-secondary/70 to-primary animate-grow-bar"
                style={{ height: `${h}%`, animationDelay: `${i * 80}ms` }}
              />
            </div>
          ))}
        </div>
        <div className="mt-2 flex justify-between text-[10px] text-muted-foreground">
          {["W1","W2","W3","W4","W5","W6","W7","W8","W9","W10"].map(w => <span key={w}>{w}</span>)}
        </div>
      </div>

      {/* glow */}
      <div className="absolute inset-0 -z-10 blur-3xl opacity-60 bg-gradient-to-br from-secondary/40 via-primary/20 to-transparent rounded-3xl" />
    </div>
  );
}