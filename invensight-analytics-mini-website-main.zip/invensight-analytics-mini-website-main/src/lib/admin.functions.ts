import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

type AppRole = "admin" | "team_lead" | "employee";

const employeeSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8).max(128),
  employee_id: z.string().min(1).max(50),
  full_name: z.string().min(1).max(120),
  role: z.enum(["admin", "team_lead", "employee"]),
  phone: z.string().max(40).optional().nullable(),
  position: z.string().max(120).optional().nullable(),
  department_id: z.string().uuid().optional().nullable(),
  team_id: z.string().uuid().optional().nullable(),
  powerbi_url: z.string().url().optional().nullable().or(z.literal("")),
});

async function assertAdmin(userId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .eq("role", "admin")
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden: admin role required");
}

/** Setup the very first admin. Only succeeds when ZERO admins exist yet. */
export const setupFirstAdmin = createServerFn({ method: "POST" })
  .inputValidator((d) =>
    z.object({
      email: z.string().email(),
      password: z.string().min(8).max(128),
      full_name: z.string().min(1).max(120),
      employee_id: z.string().min(1).max(50),
    }).parse(d),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { count } = await supabaseAdmin
      .from("user_roles")
      .select("id", { count: "exact", head: true })
      .eq("role", "admin");
    if ((count ?? 0) > 0) throw new Error("Admin already exists");

    const { data: u, error } = await supabaseAdmin.auth.admin.createUser({
      email: data.email,
      password: data.password,
      email_confirm: true,
      user_metadata: { full_name: data.full_name },
    });
    if (error || !u.user) throw new Error(error?.message ?? "Failed to create user");

    const userId = u.user.id;
    const { error: pErr } = await supabaseAdmin.from("profiles").insert({
      id: userId,
      employee_id: data.employee_id,
      full_name: data.full_name,
      email: data.email,
    });
    if (pErr) throw new Error(pErr.message);

    const { error: rErr } = await supabaseAdmin
      .from("user_roles")
      .insert({ user_id: userId, role: "admin" as AppRole });
    if (rErr) throw new Error(rErr.message);

    return { ok: true, userId };
  });

/** Admin creates an employee (or another admin / team lead). */
export const adminCreateEmployee = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => employeeSchema.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: u, error } = await supabaseAdmin.auth.admin.createUser({
      email: data.email,
      password: data.password,
      email_confirm: true,
      user_metadata: { full_name: data.full_name },
    });
    if (error || !u.user) throw new Error(error?.message ?? "Failed to create user");
    const userId = u.user.id;

    const { error: pErr } = await supabaseAdmin.from("profiles").insert({
      id: userId,
      employee_id: data.employee_id,
      full_name: data.full_name,
      email: data.email,
      phone: data.phone ?? null,
      position: data.position ?? null,
      department_id: data.department_id ?? null,
      team_id: data.team_id ?? null,
      powerbi_url: data.powerbi_url || null,
    });
    if (pErr) {
      await supabaseAdmin.auth.admin.deleteUser(userId);
      throw new Error(pErr.message);
    }

    const { error: rErr } = await supabaseAdmin
      .from("user_roles")
      .insert({ user_id: userId, role: data.role });
    if (rErr) throw new Error(rErr.message);

    return { ok: true, userId };
  });

/** Admin deletes an employee (cascades profile + roles). */
export const adminDeleteEmployee = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ user_id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    if (data.user_id === context.userId) {
      throw new Error("You cannot delete your own admin account");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.auth.admin.deleteUser(data.user_id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Admin resets an employee password. */
export const adminResetPassword = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({
      user_id: z.string().uuid(),
      password: z.string().min(8).max(128),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.auth.admin.updateUserById(data.user_id, {
      password: data.password,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });